#ifndef gy291_h
#define gy291_h
#include "Arduino.h"

class GY291 {
	
public:
	GY291();
	GY291(byte range);
	void init();
	void start();
	void stop();
	int* axis();
	void loop();
	int axis(byte axis);
	void sensitivity(byte n);
	void delay(byte n);
private:
	boolean isMove(int before,int after);
};

#endif
//
// END OF FILE
//