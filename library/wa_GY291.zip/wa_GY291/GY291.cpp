/* Include the standard wire library */
#include <Wire.h>
#include <GY291.h>
#include "Arduino.h"
#include "Firmata.h"

/* Alternate I2C address of the module */
#define I2C_Add 0x53

/* ADXL345 register addresses */
#define POWER_CTL 0x2D
#define DATA_FORMAT 0x31
#define X_Axis 0x32
#define Y_Axis 0x34
#define Z_Axis 0x36

/* Accelerometer range modes */
#define RANGE_2g 0
#define RANGE_4g 1
#define RANGE_8g 2
#define RANGE_16g 3

byte sensitive = 10, noiseRange = 100;

byte range = RANGE_2g;
boolean isRunning = false;
boolean isBegin = false;
int lastX = 0, lastY = 0, lastZ = 0;
const float alpha = 0.5;
unsigned long gy291LastTime = 0;
unsigned long gy291DelayTime = 300;

double fXg = 0;
double fYg = 0;
double fZg = 0;

GY291::GY291() {
}

GY291::GY291(byte r) {
  range = r;
}

void GY291::init() {
  if (!isBegin) {
    Wire.begin();
    isBegin = true;
  }
  /* Set the sensitivity of the module */
  Wire.beginTransmission(I2C_Add);
  Wire.write(DATA_FORMAT);
  Wire.write(range);
  Wire.endTransmission();
  /* Put the module into measurement mode to start taking measurements */
  Wire.beginTransmission(I2C_Add);
  Wire.write(POWER_CTL);
  Wire.write(0x08);
  Wire.endTransmission();
}

void GY291::start() {
  isRunning = true;
}

void GY291::stop() {
  isRunning = false;
}

/* Main program */
void GY291::loop() {
  if (!isRunning) return;
  if(millis() - gy291LastTime > gy291DelayTime){
    gy291LastTime = millis();
    int x = axis(X_Axis);
    int y = axis(Y_Axis);
    int z = axis(Z_Axis);

    if (isMove(lastX, x) || isMove(lastY, y) || isMove(lastZ, z)) {
      //*/Low Pass Filter
      Firmata.write(START_SYSEX);
      Firmata.write(0x04);  //webduino command
      Firmata.write(0x0b);  //GY-291 command
      Firmata.write(0x04);  //return axis
      Firmata.write((x + 1024) >> 8);
      Firmata.write((x + 1024) & 0xff);
      Firmata.write((y + 1024) >> 8);
      Firmata.write((y + 1024) & 0xff);
      Firmata.write((z + 1024) >> 8);
      Firmata.write((z + 1024) & 0xff);
      Firmata.write(END_SYSEX);
    }
    lastX = x;
    lastY = y;
    lastZ = z;
  }
}

int* GY291::axis() {
  int b[3];
  b[0] = axis(X_Axis);
  b[1] = axis(Y_Axis);
  b[2] = axis(Z_Axis);
  return b;
}

void GY291::sensitivity(byte i) {
  sensitive = i;
}

void GY291::delay(byte i) {
  gy291DelayTime = i * 10;
}

/* Read one of the 3 axis via the I2C interface */
int GY291::axis(byte axis)
{
  int Data;
  Wire.beginTransmission(I2C_Add);
  Wire.write(axis);
  Wire.endTransmission();
  Wire.beginTransmission(I2C_Add);
  Wire.requestFrom(I2C_Add, 2);
  /* If data is available then read it (2 bytes) */
  if (Wire.available())  {
    Data = (int)Wire.read();
    Data = Data  | (Wire.read() << 8);
  } else  {
    Data = -1;
  }
  Wire.endTransmission();
  return Data;
}

boolean GY291::isMove(int before, int after) {
  int sub = before - after;
  sub = sub < 0 ? sub * -1 : sub;
  return sub > sensitive && sub < noiseRange;
}

//
// END OF FILE
//