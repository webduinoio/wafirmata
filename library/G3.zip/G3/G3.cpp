#include "G3.h"

G3::G3(byte _rx) {
	rx = _rx;
	serial = new SoftwareSerial(rx,rx+1);
	serial->begin(9600);
	byte min = io.readByte(addressMIN);
	byte sec = io.readByte(addressSEC);
	if(min>=0 && sec>0){
		setDetectTime(min,sec);
	}
}

void G3::setDetectTime(byte min,byte sec){
	delay = ( min * 60 + sec ) * 1000;
	io.writeByte(addressMIN,min);
	io.writeByte(addressSEC,sec);
}

void G3::setEnable(boolean b){
	enable = b;
}

boolean G3::isEnable(){
	return enable;
}

void G3::loop(){
	  nowCheckTime = millis();
    if (delay>=1000 && nowCheckTime - lastCheckTime > delay) {
      lastCheckTime = nowCheckTime;
      waitData();
    }
}


void G3::waitData() {
  // put your main code here, to run repeatedly:
  int count = 0;
  unsigned char c;
  unsigned char high;
  while (serial->available()) {
    c = serial->read();
    if ((count == 0 && c != 0x42) || (count == 1 && c != 0x4d)) {
      break;
    }
    if (count > 15) {
      break;
    }
    else if (count == 4 || count == 6 || count == 8 || count == 10 || count == 12 || count == 14) high = c;
    else if (count == 11) {
      pmat10 = 256 * high + c;
    }
    else if (count == 13) {
      pmat25 = 256 * high + c;
    }
    else if (count == 15) {
      pmat100 = 256 * high + c;
    }
    count++;
  }

  while (serial->available()) {
  	serial->read();
  }
  sendData(String(pmat25)+","+String(pmat10));
}

void G3::sendData(String data) {
  Firmata.write(START_SYSEX); //sysex start
  Firmata.write(0x03); //espCmd
  Firmata.write(0x03); //cmdType
  writeString(data); //data
  Firmata.write(END_SYSEX); //sysex end
}

void G3::writeString(String data){
	  int len = data.length();
	  for(byte i=0;i<len;i++){
	  	Firmata.write(data.charAt(i));
	  }
}