#ifndef _G3_H_
#define _G3_H_

#include "Arduino.h"
#include <Firmata.h>
#include <WAEEPROM.h>
#include <SoftwareSerial.h>

class G3{
  private:
	byte rx;
    boolean enable = true;
    const int addressMIN = 20;
    const int addressSEC = 21;
    unsigned long delay = 1000;
    unsigned long lastCheckTime = 0;
    unsigned long nowCheckTime = 0;
    WAEEPROM io = WAEEPROM();
    SoftwareSerial *serial;
    long  pmcf10 = 0;
    long  pmcf25 = 0;
    long  pmcf100 = 0;
    long  pmat10 = 0;
    long  pmat25 = 0;
    long  pmat100 = 0;

  public:
    G3(byte rx);
    void loop();
    void setEnable(boolean b);
    boolean isEnable();
    void setDetectTime(byte min,byte sec);
    void waitData();
    void sendData(String data);
    void writeString(String data);
};

#endif
