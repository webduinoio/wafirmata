#include "hx711.h"
#include "Firmata.h"

HX711::HX711(){

}

void HX711::on(){
	state = true;
}

void HX711::off(){
	state = false;
}

void HX711::init(byte sck,byte dt){
	pinMode(sckPin = sck, OUTPUT);	
	pinMode(dtPin = dt, INPUT);
	delay(100);
	for(byte i=0;i<10;i++){
		unsigned long n = read()/100;
		if(n<initWeight){
			initWeight = n;
		}
	}
}

unsigned long HX711::read(void){
	unsigned long count; 
	unsigned char i;

	digitalWrite(dtPin, HIGH);
	delayMicroseconds(1);
	digitalWrite(sckPin, LOW);
	delayMicroseconds(1);
  while(digitalRead(dtPin)); 

  count=0; 
  for(i=0;i<24;i++){ 
	  digitalWrite(sckPin, HIGH); 
		delayMicroseconds(1);
	  count = count << 1; 
		digitalWrite(sckPin, LOW); 
		delayMicroseconds(1);
	  if(digitalRead(dtPin)){
	    ++count; 	
	  }
	} 
 	digitalWrite(sckPin, HIGH); 
	count ^= 0x800000;
	delayMicroseconds(1);
	digitalWrite(sckPin, LOW); 
	delayMicroseconds(1);
	return(count);
}

unsigned long HX711::getWeight(){
	unsigned long w = read()/ 100 - initWeight;
	w = (unsigned long)((float)w/4.3+0.05);
	return w > 999999 ? weight: w;
}

void HX711::loop(){
	long nowTime = millis();
	if(nowTime - lastTime > delayTime){
		lastTime = nowTime;
		weight = getWeight();
		if(state && lastWeight != weight){
			lastWeight = weight;
			sendData();
		}
	}
}

void HX711::sendData(){
//	Serial.println(weight);
	String strData = String(weight);
  byte strLen = strData.length();

  Firmata.write(START_SYSEX);
  Firmata.write(4);
  Firmata.write(0x15);

  for (byte i = 0; i < strLen; i++) {
    Firmata.write(strData.charAt(i));
  }

  Firmata.write(END_SYSEX);
}