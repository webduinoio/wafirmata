#ifndef __HX711__H__
#define __HX711__H__

#include <Arduino.h>

class HX711 {
  private:
    byte dtPin;
    byte sckPin;
    bool state;
    unsigned long read();
    void setInitWeight();
    unsigned long weight;
    unsigned long lastWeight = ~0;
    unsigned long initWeight = 0x7fffffff;
    unsigned long lastTime,delayTime = 100;
    void sendData();
    
  public:
    HX711();
    void on();
    void off();
    void loop();
    void init(byte sck, byte dt);
    unsigned long getWeight();
};

#endif