#include "MaxMatrix.h"

MaxMatrix::MaxMatrix() 
{
}

void MaxMatrix::init(byte _data, byte _load, byte _clock, byte _num)
{
	data = _data;
	load = _load;
	clock = _clock;
	num = _num;	
	pinMode(data,  OUTPUT);
	pinMode(clock, OUTPUT);
	pinMode(load,  OUTPUT);
	digitalWrite(clock, HIGH); 
	setCommand(max7219_reg_scanLimit, 0x07);      
	setCommand(max7219_reg_decodeMode, 0x00);  // using an led matrix (not digits)
	setCommand(max7219_reg_shutdown, 0x01);    // not in shutdown mode
	setCommand(max7219_reg_displayTest, 0x00); // no display test
	setIntensity(0x01);    // the first 0x0f is the value you can set
}

void MaxMatrix::setIntensity(byte intensity){
	setCommand(max7219_reg_intensity, intensity);
}


void MaxMatrix::setCommand(byte command, byte value)
{
	digitalWrite(load, LOW);    
	for (int i=0; i<num; i++) 
	{
		shiftOut(data, clock, MSBFIRST, command);
		shiftOut(data, clock, MSBFIRST, value);
	}
	digitalWrite(load, LOW);
	digitalWrite(load, HIGH);
}


void MaxMatrix::setColumn(byte col, byte value)
{
	int n = col / 8;
	int c = col % 8;
	digitalWrite(load, LOW);    
	for (int i=0; i<num; i++) 
	{
		if (i == n)
		{
			shiftOut(data, clock, MSBFIRST, c + 1);
			shiftOut(data, clock, MSBFIRST, value);
		}
		else
		{
			shiftOut(data, clock, MSBFIRST, 0);
			shiftOut(data, clock, MSBFIRST, 0);
		}
	}
	digitalWrite(load, LOW);
	digitalWrite(load, HIGH);
}

void MaxMatrix::writeLED(const byte* led){
	for(int col=0;col<8;col++){
		setColumn(col,led[col]);
	}
}

void MaxMatrix::clear(){
	for(int col=0;col<8;col++){
		setColumn(col,0x00);
	}
}