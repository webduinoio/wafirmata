#ifndef SERIAL_DATA_EXCHANGE_h
#define SERIAL_DATA_EXCHANGE_h
#include <Arduino.h>
#include <SoftwareSerial.h>


extern "C" {
  typedef void (*strCallbackFunction)(String);
}

class SerialDataExchange {
private:
	String data;
	SoftwareSerial *mySerial;
	strCallbackFunction currentStrCallbackFunction;
	public:
		SerialDataExchange(byte rx,byte tx);
		void attach(strCallbackFunction strFunction);
		void begin(unsigned long baud);
		void loop();
};

#endif // SERIAL_DATA_EXCHANGE_h