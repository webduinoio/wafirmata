#include "SerialDataExchange.h"

SerialDataExchange::SerialDataExchange(byte rx,byte tx){
	mySerial = new SoftwareSerial(rx,tx);
}

void SerialDataExchange::begin(unsigned long baud){
	mySerial->begin(baud);
}

void SerialDataExchange::attach(strCallbackFunction newFunction){
	currentStrCallbackFunction = newFunction;
}

void SerialDataExchange::loop(){
	  while (mySerial->available()) {
    char character = mySerial->read();
    if (character == 0x0D) {
    	currentStrCallbackFunction(data);
      data = "";
    } else {
      data.concat(character);
    }
  }
}