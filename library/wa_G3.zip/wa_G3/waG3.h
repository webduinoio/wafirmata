#ifndef _WAG3_H_
#define _WAG3_H_

#include "Arduino.h"
#include <Firmata.h>
#include <SoftwareSerial.h>

class waG3 {
  private:
	byte rx,tx;
    boolean enable = true;
    SoftwareSerial *serial;
    long  pmcf10 = 0;
    long  pmcf25 = 0;
    long  pmcf100 = 0;
    long  pmat10 = 0;
    long  pmat25 = 0;
    long  pmat100 = 0;

  public:
    waG3(byte rx,byte tx);
    void setEnable(boolean b);
    boolean isEnable();
    String getData();
};

#endif
