#include "waG3.h"

waG3::waG3(byte _rx,byte _tx) {
	rx = _rx;
  tx = _tx;
	serial = new SoftwareSerial(rx,tx);
	serial->begin(9600);
}


void waG3::setEnable(boolean b){
	enable = b;
}

boolean waG3::isEnable(){
	return enable;
}

String waG3::getData() {
  // put your main code here, to run repeatedly:
  int count = 0;
  unsigned char c;
  unsigned char high;
  while (serial->available()) {
    c = serial->read();
    if ((count == 0 && c != 0x42) || (count == 1 && c != 0x4d)) {
      break;
    }
    if (count > 15) {
      break;
    }
    else if (count == 4 || count == 6 || count == 8 || count == 10 || count == 12 || count == 14) high = c;
    else if (count == 11) {
      pmat10 = 256 * high + c;
    }
    else if (count == 13) {
      pmat25 = 256 * high + c;
    }
    else if (count == 15) {
      pmat100 = 256 * high + c;
    }
    count++;
  }

  while (serial->available()) {
  	serial->read();
  }
  return String(pmat25)+","+String(pmat10);
}
